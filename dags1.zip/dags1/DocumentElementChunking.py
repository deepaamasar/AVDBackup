import re, json
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

# ------------- Lightweight element detectors (plain text / Markdown-ish) -------------

HEADING_LINE = re.compile(r"^(#{1,6})\s+(.*)$")          # #, ##, ...
UNDERLINE_H1 = re.compile(r"^=+$")                       # Setext ===
UNDERLINE_H2 = re.compile(r"^-+$")                       # Setext ---
LIST_BULLET  = re.compile(r"^\s*[-*+]\s+(.+)$")
LIST_NUM     = re.compile(r"^\s*\d+[.)]\s+(.+)$")
TABLE_ROW    = re.compile(r"^\s*\|.*\|\s*$")             # | a | b |
CODE_FENCE   = re.compile(r"^\s*```")                    # ``` code
FORM_FEED    = "\f"

def _is_heading(lines: List[str], i: int) -> Tuple[bool, int, str, int]:
    """Return (is_heading, level, text, next_index). Handles #..###### and Setext."""
    line = lines[i].rstrip()
    m = HEADING_LINE.match(line)
    if m:
        return True, len(m.group(1)), m.group(2).strip(), i + 1
    if i + 1 < len(lines):
        nxt = lines[i + 1].rstrip()
        if UNDERLINE_H1.match(nxt) and line.strip():
            return True, 1, line.strip(), i + 2
        if UNDERLINE_H2.match(nxt) and line.strip():
            return True, 2, line.strip(), i + 2
    return False, 0, "", i

def _is_list(line: str) -> Tuple[bool, str]:
    m = LIST_BULLET.match(line)
    if m:
        return True, m.group(1).strip()
    m = LIST_NUM.match(line)
    if m:
        return True, m.group(1).strip()
    return False, ""

def _is_table_row(line: str) -> bool:
    return bool(TABLE_ROW.match(line))

def text_to_elements(text: str) -> List[Dict[str, Any]]:
    """Plain-text → elements: heading / paragraph / list / code / table / pagebreak."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")

    elements: List[Dict[str, Any]] = []
    i, in_code, code_buf = 0, False, []
    para_buf: List[str] = []

    def flush_para():
        if not para_buf: return
        para = " ".join(" ".join(l.split()) for l in para_buf).strip()
        if para:
            elements.append({"type": "paragraph", "text": para})
        para_buf.clear()

    while i < len(lines):
        line = lines[i]

        # page breaks
        if line.strip() == FORM_FEED:
            flush_para()
            elements.append({"type": "pagebreak", "text": ""})
            i += 1
            continue

        # code fences
        if CODE_FENCE.match(line):
            if in_code:
                elements.append({"type": "code", "text": "\n".join(code_buf).rstrip("\n")})
                code_buf.clear()
                in_code = False
            else:
                flush_para()
                in_code = True
            i += 1
            continue

        if in_code:
            code_buf.append(line)
            i += 1
            continue

        # blank line ends a paragraph
        if not line.strip():
            flush_para()
            i += 1
            continue

        # heading?
        is_h, level, htext, nxt = _is_heading(lines, i)
        if is_h:
            flush_para()
            elements.append({"type": "heading", "level": level, "text": htext})
            i = nxt
            continue

        # table block?
        if _is_table_row(line):
            flush_para()
            rows = [line]
            j = i + 1
            while j < len(lines) and _is_table_row(lines[j]):
                rows.append(lines[j]); j += 1
            t_rows = []
            for r in rows:
                cells = [c.strip() for c in r.strip().strip("|").split("|")]
                t_rows.append("\t".join(cells))
            elements.append({"type": "table", "text": "\n".join(t_rows)})
            i = j
            continue

        # list block?
        ok, item = _is_list(line)
        if ok:
            flush_para()
            items = [item]
            j = i + 1
            while j < len(lines):
                ok2, item2 = _is_list(lines[j])
                if ok2:
                    items.append(item2); j += 1
                else:
                    break
            elements.append({"type": "list", "items": items, "text": "\n".join(items)})
            i = j
            continue

        # otherwise, paragraph accumulation
        para_buf.append(line)
        i += 1

    if in_code and code_buf:
        elements.append({"type": "code", "text": "\n".join(code_buf).rstrip("\n")})
    if para_buf:
        flush_para()

    return elements

# ------------- Packing with token or char budgets -------------

def _render(el: Dict[str, Any]) -> str:
    t = el["type"]
    if t == "heading":  return f"[H{el.get('level',1)}] {el['text']}"
    if t == "paragraph":return f"[P] {el['text']}"
    if t == "list":     return "[LIST]\n- " + "\n- ".join(el.get("items") or el["text"].splitlines())
    if t == "code":     return "[CODE]\n" + el["text"]
    if t == "table":    return "[TABLE]\n" + el["text"]
    if t == "pagebreak":return "[PAGEBREAK]"
    return f"[{t.upper()}] {el.get('text','')}"

def pack_elements_token_budget(
    elements: List[Dict[str, Any]],
    max_tokens: int = 800,
    overlap_tokens: int = 120,
    model: str = "gpt-4o-mini",
) -> List[Dict[str, Any]]:
    """
    Token-aware packer (requires tiktoken). Keeps element boundaries, adds overlap.
    Falls back to char-based if tiktoken unavailable.
    """
    try:
        import tiktoken
    except Exception:
        # fallback to char-based
        return pack_elements_char_budget(elements, max_chars=max_tokens*4, overlap_chars=overlap_tokens*4)

    enc = tiktoken.get_encoding("cl100k_base") if model is None else tiktoken.encoding_for_model(model)

    chunks, cur_blocks, cur_meta = [], [], []

    def cur_tokens():
        text = "\n\n".join(cur_blocks)
        return len(enc.encode(text))

    for el in elements:
        block = _render(el)
        # try adding
        cur_blocks.append(block); cur_meta.append(el)
        if cur_tokens() > max_tokens:
            # remove last, emit previous
            cur_blocks.pop(); cur_meta.pop()
            if cur_blocks:
                text = "\n\n".join(cur_blocks)
                chunks.append({"text": text, "elements": cur_meta})
                # overlap tail
                if overlap_tokens > 0:
                    tail_ids = enc.encode(text)[-overlap_tokens:]
                    tail_text = enc.decode(tail_ids)
                    cur_blocks = [f"[OVERLAP]\n{tail_text}"]; cur_meta = []
                else:
                    cur_blocks, cur_meta = [], []
            # now start with the big block (may itself exceed; then we hard-split by chars)
            cur_blocks.append(block); cur_meta.append(el)
            if cur_tokens() > max_tokens:
                # hard split by characters as last resort
                bt = block
                step = max(200, int(max_tokens * 4))  # approx char budget
                k = 0
                while k < len(bt):
                    piece = bt[k:k+step]
                    if cur_blocks:
                        text = "\n\n".join(cur_blocks + [piece])
                        if len(enc.encode(text)) > max_tokens:
                            # emit current and start new
                            chunks.append({"text": "\n\n".join(cur_blocks), "elements": cur_meta})
                            if overlap_tokens > 0:
                                tail_ids = enc.encode("\n\n".join(cur_blocks))[-overlap_tokens:]
                                cur_blocks = [f"[OVERLAP]\n{enc.decode(tail_ids)}"]; cur_meta = []
                            else:
                                cur_blocks, cur_meta = [], []
                    cur_blocks.append(piece); cur_meta.append({"type":"paragraph","text":"[SPLIT]"})
                    k += step
    if cur_blocks:
        chunks.append({"text": "\n\n".join(cur_blocks), "elements": cur_meta})
    return chunks

def pack_elements_char_budget(
    elements: List[Dict[str, Any]],
    max_chars: int = 3000,
    overlap_chars: int = 400,
) -> List[Dict[str, Any]]:
    chunks, cur_blocks, cur_meta = [], [], []
    def cur_len(): return sum(len(b) for b in cur_blocks) + max(0, len(cur_blocks)-1)*2
    for el in elements:
        block = _render(el)
        if cur_blocks and cur_len() + 2 + len(block) > max_chars:
            text = "\n\n".join(cur_blocks)
            chunks.append({"text": text, "elements": cur_meta})
            # char overlap
            if overlap_chars > 0:
                tail = text[-overlap_chars:]
                cur_blocks = [f"[OVERLAP]\n{tail}"]; cur_meta = []
            else:
                cur_blocks, cur_meta = [], []
        cur_blocks.append(block); cur_meta.append(el)
    if cur_blocks:
        chunks.append({"text": "\n\n".join(cur_blocks), "elements": cur_meta})
    return chunks

# ------------- Example CLI -------------
if __name__ == "__main__":
    # Change this to your file
    INFILE = Path("C://docker//data//sample.txt")  # e.g., r"C:\path\to\your\sample.txt"
    text = INFILE.read_text(encoding="utf-8")

    elements = text_to_elements(text)
    # Prefer token-aware packing if tiktoken is installed
    chunks = pack_elements_token_budget(elements, max_tokens=800, overlap_tokens=120, model="gpt-4o-mini")

    out = Path("C:/docker/data/Out"); out.mkdir(exist_ok=True, parents=True)
    (out / "elements.jsonl").write_text("\n".join(json.dumps(e, ensure_ascii=False) for e in elements), encoding="utf-8")
    (out / "chunks.jsonl").write_text("\n".join(json.dumps(c, ensure_ascii=False) for c in chunks), encoding="utf-8")
    print(f"Parsed {len(elements)} elements → {len(chunks)} chunks")
