from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import logging

def log_step(step_name, **kwargs):
    run_id = kwargs["run_id"]
    ti = kwargs["ti"]

    logging.info({
        "event": "STEP_STARTED",
        "step": step_name,
        "run_id": run_id,
        "task_id": ti.task_id,
        "dag_id": ti.dag_id,
        "timestamp": datetime.utcnow().isoformat()
    })

    # simulate work
    logging.info({
        "event": "STEP_COMPLETED",
        "step": step_name,
        "run_id": run_id,
        "task_id": ti.task_id,
        "dag_id": ti.dag_id,
        "timestamp": datetime.utcnow().isoformat()
    })

with DAG(
    dag_id="etl_story_dag",
    start_date=datetime(2025, 9, 16),
    schedule=None,
    catchup=False,
) as dag:

    extract = PythonOperator(
        task_id="extract",
        python_callable=log_step,
        op_args=["Extract"],
    )

    transform = PythonOperator(
        task_id="transform",
        python_callable=log_step,
        op_args=["Transform"],
    )

    load = PythonOperator(
        task_id="load",
        python_callable=log_step,
        op_args=["Load"],
    )

    extract >> transform >> load
