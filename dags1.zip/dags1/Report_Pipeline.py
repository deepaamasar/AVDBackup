# dags/report_pipeline.py
from datetime import datetime
from airflow import DAG
from airflow.decorators import task
from airflow.models.param import Param
from datetime import datetime, timedelta

with DAG(
    dag_id="report_pipeline",
    start_date=datetime.now() - timedelta(days=1),
    schedule=None, 
    catchup=False,
    params={
        "country": Param("IN", type="string", minLength=2, maxLength=3),
        "start_date": Param("2025-08-01", type="string", pattern=r"^\d{4}-\d{2}-\d{2}$"),
        "threshold": Param(0.8, type="number", ge=0, le=1),
    },
) as dag:

    @task
    def run_report(**context):
        # Read runtime conf with safe defaults from params
        conf = (context["dag_run"].conf or {})
        p = context["params"]

        country   = conf.get("country",   p["country"])
        start_dt  = conf.get("start_date",p["start_date"])
        threshold = float(conf.get("threshold", p["threshold"]))

        # Your logic here
        print(f"[run_report] country={country} start_date={start_dt} threshold={threshold}")
        return {"country": country, "start_date": start_dt, "threshold": threshold}

    run_report()
