from airflow import DAG
from airflow.operators.python import PythonOperator # type: ignore
from datetime import datetime
import logging

def log_step(**context):
    dag_id = context["dag"].dag_id
    task_id = context["task"].task_id
    run_id = context["run_id"]

    logging.info(f"STEP START - dag_id={dag_id} run_id={run_id} task_id={task_id}")

    # simulate work
    logging.info(f"Doing work in task {task_id}...")

    logging.info(f"STEP END - dag_id={dag_id} run_id={run_id} task_id={task_id}")

with DAG(
    "etl_story_dag",
    start_date=datetime(2023, 1, 1),
    schedule=None,
    catchup=False,
) as dag:

    extract = PythonOperator(
        task_id="extract",
        python_callable=log_step,
    )

    transform = PythonOperator(
        task_id="transform",
        python_callable=log_step,
    )

    load = PythonOperator(
        task_id="load",
        python_callable=log_step,
    )

    extract >> transform >> load
