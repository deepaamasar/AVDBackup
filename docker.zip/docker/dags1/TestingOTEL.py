from __future__ import annotations

import random
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.decorators import task

# Optional: create custom spans inside tasks (Airflow already emits task spans if OTEL tracing is on)
try:
    from opentelemetry import trace
    tracer = trace.get_tracer(__name__)
except Exception:  # if OTEL libs are missing, tasks still run
    tracer = None

default_args = {
    "owner": "you",
    "retries": 2,                    # will create retry metrics/signals
    "retry_delay": timedelta(seconds=20),
}

# Run every 5 minutes so Prometheus sees steady activity; trigger manually if you prefer
with DAG(
    dag_id="otel_prom_grafana_check",
    start_date=datetime(2024, 1, 1),
    schedule="*/5 * * * *",         # change to None if you want manual only
    catchup=False,
    default_args=default_args,
    tags=["observability", "otel", "prometheus", "grafana"],
) as dag:

    @task
    def ping():
        # This creates a small custom child span (optional)
        if tracer:
            with tracer.start_as_current_span("custom_span_ping"):
                time.sleep(0.5)
        print("Hello OTEL! Emitting logs for task_log_event=True.")
        return "pong"

    @task
    def cpu_work(n: int = 5_000_00):
        # Simple CPU loop to produce measurable duration
        if tracer:
            with tracer.start_as_current_span("custom_span_cpu"):
                s = 0
                for i in range(n):
                    s += i % 97
        else:
            s = sum(i % 97 for i in range(n))
        return s

    @task
    def io_wait(seconds: float = 2.0):
        if tracer:
            with tracer.start_as_current_span("custom_span_sleep"):
                time.sleep(seconds)
        else:
            time.sleep(seconds)
        return f"slept_{seconds}s"

    @task
    def sometimes_flaky(p_fail: float = 0.35):
        # Random failure to exercise retries/failed metrics
        r = random.random()
        print(f"flaky roll={r:.3f}, p_fail={p_fail:.2f}")
        if r < p_fail:
            raise RuntimeError("Intentional flaky failure to test retries/alerts")
        return "ok"

    # simple fan-out to create multiple task instances per run
    res_ping = ping()
    res_cpu  = cpu_work()
    res_io   = io_wait()
    res_flaky = sometimes_flaky()

    # Make a trivial dependency graph
    res_ping >> [res_cpu, res_io, res_flaky]
