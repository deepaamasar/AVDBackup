#!/usr/bin/env python3
# vlm_ocr_dehallucinate_wordmatch.py
import argparse
import csv
import json
import os
import re
import sys
from typing import List, Dict, Tuple, Optional

# ============================================================
# Basic text utilities
# ============================================================
STOPWORDS = {
    "a","an","and","are","as","at","be","by","for","from","has","he","in","is","it",
    "its","of","on","that","the","to","was","were","will","with","this","these","those",
    "or","if","not","but","so","than","then","there","their","they","you","your","we","our"
}

def normalize_text(s: str) -> str:
    s = s or ""
    s = s.lower()
    # unify number formatting: 1,234,567 -> 1234567 ; 1.234.567 -> 1234567
    s = re.sub(r'(?<=\d)[,\.](?=\d{3}\b)', '', s)
    # collapse whitespace
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def tokenize(s: str, keep_stopwords: bool=False) -> List[str]:
    s = normalize_text(s)
    # keep letters, digits, % and currency symbols together; split everything else
    s = re.sub(r"[^0-9a-zA-Z₹€$£%]+", " ", s)
    toks = [t for t in s.split() if t]
    if not keep_stopwords:
        toks = [t for t in toks if t not in STOPWORDS]
    return toks

# ============================================================
# File IO helpers
# ============================================================
def read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def read_json_file(path: str):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return json.load(f)

def read_csv_rows(path: str) -> List[List[str]]:
    rows = []
    with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            rows.append(row)
    return rows

# ============================================================
# Markdown table parsing
# ============================================================
def is_markdown_table(text: str) -> bool:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    pipe_lines = sum(1 for ln in lines if "|" in ln)
    sep_lines = sum(1 for ln in lines if re.search(r"^\s*\|?\s*:?-{3,}", ln))
    return pipe_lines >= 2 and sep_lines >= 1

def parse_markdown_table(text: str):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    table_lines = [ln for ln in lines if "|" in ln and not re.match(r"^\s*\|?\s*:?-{3,}", ln)]
    rows = []
    for ln in table_lines:
        parts = [c.strip() for c in ln.split("|")]
        if parts and parts[0] == "": parts = parts[1:]
        if parts and parts[-1] == "": parts = parts[:-1]
        if parts:
            rows.append(parts)
    if not rows:
        return None
    headers, data = rows[0], rows[1:]
    return {"headers": headers, "rows": data}

# ============================================================
# Chunking / Flattening
# ============================================================
def chunk_text(text: str) -> List[str]:
    text = (text or "").replace("\r\n", "\n")
    lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
    if len(lines) >= 3:
        return [normalize_text(ln) for ln in lines]
    sentences = re.split(r"(?<=[.!?])\s+|[\n]", text)
    return [normalize_text(s) for s in sentences if normalize_text(s)]

def flatten_table_rows(rows: List[List[str]], headers: Optional[List[str]]=None) -> List[str]:
    flat = []
    for r in rows or []:
        if headers and len(headers) == len(r):
            pairs = [f"{str(h).strip()}: {str(v).strip()}" for h, v in zip(headers, r)]
            flat.append(" | ".join(pairs))
        else:
            flat.append(" | ".join(str(x).strip() for x in r))
    return flat

# ============================================================
# VLM → JSON normalization
# ============================================================
def vlm_to_json_from_file(vlm_path: str) -> dict:
    ext = os.path.splitext(vlm_path.lower())[1]
    if ext == ".json":
        try:
            obj = read_json_file(vlm_path)
            if isinstance(obj, dict) and ("table" in obj or "text" in obj):
                return obj
            if isinstance(obj, dict):
                if "table" in obj and isinstance(obj["table"], dict):
                    return obj
                if "rows" in obj and isinstance(obj["rows"], list):
                    return {"table": {"headers": obj.get("headers"), "rows": obj["rows"]}}
                if "data" in obj and isinstance(obj["data"], list):
                    return {"table": {"headers": obj.get("headers"), "rows": obj["data"]}}
                for k in ("text", "content", "answer"):
                    if k in obj and isinstance(obj[k], str):
                        return {"text": obj[k]}
            if isinstance(obj, list):
                if obj and isinstance(obj[0], list):
                    return {"table": {"headers": None, "rows": obj}}
                if obj and isinstance(obj[0], str):
                    return {"text": "\n".join(obj)}
            return {"text": json.dumps(obj, ensure_ascii=False)}
        except Exception:
            pass

    if ext in {".csv", ".tsv"}:
        rows = read_csv_rows(vlm_path)
        if not rows:
            return {"text": ""}
        headers = rows[0] if rows else None
        is_header = headers and any(re.search(r"[A-Za-z]", str(h)) for h in headers)
        data_rows = rows[1:] if is_header else rows
        return {"table": {"headers": headers if is_header else None, "rows": data_rows}}

    # text / markdown
    text = read_text_file(vlm_path)
    if is_markdown_table(text):
        tbl = parse_markdown_table(text)
        return {"table": tbl} if tbl else {"text": text}
    return {"text": text}

def vlm_chunks_from_json(vlm_json: dict) -> Tuple[List[str], List[Dict], Dict]:
    if "table" in vlm_json and isinstance(vlm_json["table"], dict):
        headers = vlm_json["table"].get("headers")
        rows = vlm_json["table"].get("rows") or []
        chunks = flatten_table_rows(rows, headers if headers else None)
        index_map = [{"type": "row", "row_index": i} for i in range(len(rows))]
        shape = {"kind": "table", "headers": headers, "rows_len": len(rows)}
        return chunks, index_map, shape

    text = vlm_json.get("text", "") or ""
    lines = chunk_text(text)
    index_map = [{"type": "line", "line_index": i} for i in range(len(lines))]
    shape = {"kind": "text", "lines_len": len(lines)}
    return lines, index_map, shape

# ============================================================
# OCR chunks
# ============================================================
def extract_ocr_chunks(ocr_path: str) -> List[str]:
    ext = os.path.splitext(ocr_path.lower())[1]
    if ext in {".csv", ".tsv"}:
        rows = read_csv_rows(ocr_path)
        return flatten_table_rows(rows, None)
    text = read_text_file(ocr_path)
    return chunk_text(text)

# ============================================================
# Word-overlap metrics
# ============================================================
def word_overlap_score(a: str, b: str, metric: str="containment", keep_stopwords: bool=False) -> int:
    """
    Returns 0..100
    - containment: |A∩B| / |A|
    - jaccard: |A∩B| / |A∪B|
    - f1: 2 * (precision * recall) / (precision + recall)
      precision = |A∩B| / |A| ; recall = |A∩B| / |B|
    Where A = tokens(a), B = tokens(b)
    """
    A = set(tokenize(a, keep_stopwords))
    B = set(tokenize(b, keep_stopwords))
    if not A and not B:
        return 100
    if not A:
        return 0
    inter = len(A & B)
    if metric == "containment":
        denom = len(A)
        return int(100 * inter / denom) if denom else 0
    elif metric == "jaccard":
        union = len(A | B)
        return int(100 * inter / union) if union else 0
    else:  # f1
        precision = inter / len(A) if A else 0.0
        recall = inter / len(B) if B else 0.0
        if precision + recall == 0:
            return 0
        f1 = 2 * precision * recall / (precision + recall)
        return int(100 * f1)

# ============================================================
# Matching (supports word or fuzzy)
# ============================================================
def score_pair(a: str, b: str, metric: str, word_metric: str, keep_stopwords: bool):
    if metric == "word_overlap":
        return word_overlap_score(a, b, metric=word_metric, keep_stopwords=keep_stopwords)
    # fallback: fuzzy (RapidFuzz or difflib)
    try:
        from rapidfuzz import fuzz  # type: ignore
        return fuzz.token_set_ratio(normalize_text(a), normalize_text(b))
    except Exception:
        from difflib import SequenceMatcher
        return int(SequenceMatcher(None, normalize_text(a), normalize_text(b)).ratio() * 100)

def match_keep_vlm(vlm_chunks: List[str],
                   ocr_chunks: List[str],
                   threshold: float,
                   metric: str,
                   word_metric: str,
                   scope: str,
                   keep_stopwords: bool):
    report = []
    if not ocr_chunks:
        return [0]*len(vlm_chunks), [{"vlm_chunk": vc, "best_ocr_match": "", "score": 0, "keep": 0} for vc in vlm_chunks]

    keep_mask = []
    if scope == "global":
        ocr_all = " ".join(ocr_chunks)
        for vc in vlm_chunks:
            sc = score_pair(vc, ocr_all, metric, word_metric, keep_stopwords)
            keep = 1 if sc >= int(threshold * 100) else 0
            keep_mask.append(keep)
            report.append({
                "vlm_chunk": vc,
                "best_ocr_match": "(global)",
                "score": sc,
                "keep": keep
            })
    else:
        ocr_norm = ocr_chunks
        for vc in vlm_chunks:
            best_score = -1
            best_ocr = ""
            for oc in ocr_norm:
                sc = score_pair(vc, oc, metric, word_metric, keep_stopwords)
                if sc > best_score:
                    best_score = sc
                    best_ocr = oc
            keep = 1 if best_score >= int(threshold * 100) else 0
            keep_mask.append(keep)
            report.append({
                "vlm_chunk": vc,
                "best_ocr_match": best_ocr,
                "score": best_score,
                "keep": keep
            })
    return keep_mask, report

def match_keep_ocr(ocr_chunks: List[str],
                   vlm_chunks: List[str],
                   threshold: float,
                   metric: str,
                   word_metric: str,
                   scope: str,
                   keep_stopwords: bool):
    kept = []
    report = []
    if not vlm_chunks:
        return kept, [{"ocr_chunk": oc, "best_vlm_match": "", "score": 0, "keep": 0} for oc in ocr_chunks]

    if scope == "global":
        vlm_all = " ".join(vlm_chunks)
        for oc in ocr_chunks:
            sc = score_pair(oc, vlm_all, metric, word_metric, keep_stopwords)
            keep = 1 if sc >= int(threshold * 100) else 0
            if keep: kept.append(oc)
            report.append({"ocr_chunk": oc, "best_vlm_match": "(global)", "score": sc, "keep": keep})
    else:
        for oc in ocr_chunks:
            best_score = -1
            best_v = ""
            for vc in vlm_chunks:
                sc = score_pair(oc, vc, metric, word_metric, keep_stopwords)
                if sc > best_score:
                    best_score = sc
                    best_v = vc
            keep = 1 if best_score >= int(threshold * 100) else 0
            if keep: kept.append(oc)
            report.append({"ocr_chunk": oc, "best_vlm_match": best_v, "score": best_score, "keep": keep})
    return kept, report

# ============================================================
# Writers
# ============================================================
def write_report_csv(path: str, rows: List[Dict], fieldnames: List[str]):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def write_filtered_vlm_json(out_path: str, vlm_json: dict, keep_mask: List[int]):
    if "table" in vlm_json and isinstance(vlm_json["table"], dict):
        headers = vlm_json["table"].get("headers")
        rows = vlm_json["table"].get("rows") or []
        if len(rows) != len(keep_mask):
            raise ValueError("keep_mask length does not match VLM rows/lines length")
        kept_rows = [row for row, keep in zip(rows, keep_mask) if keep == 1]
        out = {"table": {"headers": headers, "rows": kept_rows}}
    else:
        text = vlm_json.get("text", "") or ""
        lines = chunk_text(text)
        if len(lines) != len(keep_mask):
            # best-effort fallback
            kept_lines = [ln for ln, keep in zip(lines, keep_mask) if keep == 1]
        else:
            kept_lines = [ln for ln, keep in zip(lines, keep_mask) if keep == 1]
        out = {"text": "\n".join(kept_lines)}
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

def write_filtered_text(path: str, chunks: List[str]):
    with open(path, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(c.strip() + "\n")

# ============================================================
# CLI
# ============================================================
def main():
    ap = argparse.ArgumentParser(
        description="Validate VLM output against OCR to remove hallucinations. "
                    "Supports word-level matching and two modes: keep_vlm or keep_ocr."
    )
    ap.add_argument("--ocr", required=True, help="Path to OCR output (.txt/.csv)")
    ap.add_argument("--vlm", required=True, help="Path to VLM output (.txt/.csv/.md/.json)")
    ap.add_argument("--threshold", type=float, default=0.60, help="Similarity threshold (0.0-1.0). Default 0.60")
    ap.add_argument("--mode", choices=["keep_vlm", "keep_ocr"], default="keep_vlm",
                    help="keep_vlm: keep VLM chunks if OCR confirms; keep_ocr: keep OCR chunks if VLM confirms.")
    # NEW: word matching knobs
    ap.add_argument("--metric", choices=["word_overlap", "fuzzy"], default="word_overlap",
                    help="word_overlap = token overlap (recommended); fuzzy = RapidFuzz/difflib.")
    ap.add_argument("--word_metric", choices=["containment","jaccard","f1"], default="containment",
                    help="Word-overlap formula. Default: containment (|VLM∩OCR| / |VLM|).")
    ap.add_argument("--scope", choices=["chunk","global"], default="chunk",
                    help="chunk: compare against best single chunk; global: compare against all OCR text combined.")
    ap.add_argument("--keep_stopwords", action="store_true",
                    help="If set, keep stopwords during tokenization (default removes them).")
    ap.add_argument("--out", default=None,
                    help="Output path. Default: filtered_vlm.json (keep_vlm) or filtered_ocr.txt (keep_ocr).")
    ap.add_argument("--report", default="match_report.csv", help="CSV report path.")
    args = ap.parse_args()

    if args.out is None:
        args.out = "filtered_vlm.json" if args.mode == "keep_vlm" else "filtered_ocr.txt"

    # Load OCR
    ocr_chunks = extract_ocr_chunks(args.ocr)
    if not ocr_chunks:
        print("WARNING: No OCR chunks found.", file=sys.stderr)

    # Load + normalize VLM → JSON
    vlm_json = vlm_to_json_from_file(args.vlm)
    vlm_chunks, index_map, shape = vlm_chunks_from_json(vlm_json)

    # Match
    if args.mode == "keep_vlm":
        keep_mask, report = match_keep_vlm(
            vlm_chunks, ocr_chunks, args.threshold, args.metric, args.word_metric, args.scope, args.keep_stopwords
        )
        write_report_csv(args.report, report, ["vlm_chunk", "best_ocr_match", "score", "keep"])
        write_filtered_vlm_json(args.out, vlm_json, keep_mask)
        kept_n = sum(keep_mask); total = len(keep_mask)
        print(f"[keep_vlm/{args.metric}:{args.word_metric}|{args.scope}] Kept {kept_n}/{total} VLM chunks (threshold={int(args.threshold*100)}).")
        print(f"Filtered VLM JSON → {args.out}")
        print(f"Match report → {args.report}")
    else:
        kept_ocr, report = match_keep_ocr(
            ocr_chunks, vlm_chunks, args.threshold, args.metric, args.word_metric, args.scope, args.keep_stopwords
        )
        write_report_csv(args.report, report, ["ocr_chunk", "best_vlm_match", "score", "keep"])
        write_filtered_text(args.out, kept_ocr)
        kept_n = sum(1 for r in report if r["keep"] == 1); total = len(report)
        print(f"[keep_ocr/{args.metric}:{args.word_metric}|{args.scope}] Kept {kept_n}/{total} OCR chunks (threshold={int(args.threshold*100)}).")
        print(f"Filtered OCR text → {args.out}")
        print(f"Match report → {args.report}")

if __name__ == "__main__":
    main()
