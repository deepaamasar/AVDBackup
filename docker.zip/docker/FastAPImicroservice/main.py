from fastapi import FastAPI
from routers import ingest, search, health

app = FastAPI(title="Document Ingestion Service")

# include routers
app.include_router(health.router)
app.include_router(ingest.router)
app.include_router(search.router)
