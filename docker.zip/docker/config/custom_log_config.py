from airflow.config_templates.airflow_local_settings import DEFAULT_LOGGING_CONFIG
from pythonjsonlogger import jsonlogger

# Copy Airflow’s default config so we don’t break SecretsMasker or task_log_reader
LOGGING_CONFIG = DEFAULT_LOGGING_CONFIG.copy()

# Define a JSON formatter
LOGGING_CONFIG["formatters"]["json"] = {
    "()": jsonlogger.JsonFormatter,
    "format": "%(asctime)s %(levelname)s %(name)s %(message)s",
}

# Switch the default task handler to JSON formatter
if "task" in LOGGING_CONFIG.get("handlers", {}):
    LOGGING_CONFIG["handlers"]["task"]["formatter"] = "json"

# Switch the scheduler handler too, if present
if "scheduler" in LOGGING_CONFIG.get("handlers", {}):
    LOGGING_CONFIG["handlers"]["scheduler"]["formatter"] = "json"

# (Optional) also override root logger to use JSON
if "root" in LOGGING_CONFIG:
    LOGGING_CONFIG["root"]["handlers"] = list(LOGGING_CONFIG["handlers"].keys())
    for h in LOGGING_CONFIG["handlers"].values():
        h["formatter"] = "json"
