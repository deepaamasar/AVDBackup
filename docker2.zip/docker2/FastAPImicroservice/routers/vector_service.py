import uuid
import requests
import os
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct
from qdrant_client.http.models import VectorParams, Distance, ScalarQuantization, ScalarQuantizationConfig, ScalarType
from utils.config import EMBEDDINGS_API_URL, MODEL_NAME, QDRANT_URL, QDRANT_COLLECTION
from qdrant_client.http.exceptions import UnexpectedResponse

def chunk_text(text: str, strategy: str) -> list[str]:
        import re
        params = get_current_context()["params"]
        strategy = params["ChunkingStrategy"]
        chunk_size=int(params["ChunkSize"])
        if strategy == "Fixed":
            # Fixed size chunking (e.g., 500 words)
            words = text.split()
            print("Fixed Chunking Strategy Used")
            return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]
        elif strategy == "sentence":
            # Sentence-based chunking using regex (e.g., 5 sentences per chunk)
            # Splits on punctuation followed by whitespace and capital letter
            sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text.strip())
            chunk_size = 5
            print("Sentence Chunking Strategy Used")
            return [" ".join(sentences[i:i+chunk_size]) for i in range(0, len(sentences), chunk_size)]
        elif strategy == "heading":
            # Header based chunking (split on headings)
            chunks = re.split(r"(?:^|\n)(?:#+\s|[A-Z][A-Z\s]+:|\d+\.\s)", text)
            print("Heading Chunking Strategy Used")
            return [c.strip() for c in chunks if c.strip()]
        elif strategy == "semantic":
            # Semantic chunking using topic modeling (simple LDA example)
            from sklearn.feature_extraction.text import CountVectorizer
            from sklearn.decomposition import LatentDirichletAllocation
            paras = [p for p in text.split("\n\n") if p.strip()]
            if len(paras) < 2:
                return paras
            vectorizer = CountVectorizer(stop_words='english')
            X = vectorizer.fit_transform(paras)
            lda = LatentDirichletAllocation(n_components=min(3, len(paras)), random_state=42)
            print("Semantic Chunking Strategy Used")
            topics = lda.fit_transform(X)
            topic_assignments = topics.argmax(axis=1)
            chunks = {}
            for idx, topic in enumerate(topic_assignments):
                chunks.setdefault(topic, []).append(paras[idx])
            return ["\n\n".join(chunk) for chunk in chunks.values()]
        elif strategy == "agentic":
            # Agentic chunking using locally hosted Deepseek LLM
            OLLAMA_LLM_URL = "http://host.docker.internal:11434/api/generate"
            prompt = (
                "You are an expert document chunker. Split the following text into logical, meaningful sections. "
                "Return a JSON list of strings, each string is a chunk.\nTEXT:\n" + text[:8000]
            )
            r = requests.post(OLLAMA_LLM_URL, json={"model": "deepseek-coder:latest", "prompt": prompt})
            print("Agentic Chunking Strategy Used")
            r.raise_for_status()
            import json as _json
            try:
                return _json.loads(r.json()["choices"][0]["text"])
            except Exception:
                return [text]
        elif strategy == "hybrid":
            # Hybrid: combine heading and fixed size
            # First split by heading, then further split large chunks by fixed size
            heading_chunks = re.split(r"(?:^|\n)(?:#+\s|[A-Z][A-Z\s]+:|\d+\.\s)", text)
            print("Hybrid Chunking Strategy Used")
            final_chunks = []
            chunk_size = 500
            for chunk in heading_chunks:
                words = chunk.split()
                if len(words) > chunk_size:
                    final_chunks.extend([" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)])
                elif chunk.strip():
                    final_chunks.append(chunk.strip())
            return final_chunks
        else:
            # Default: paragraph split
            print("Default Chunking Strategy Used")
            return [chunk.strip() for chunk in text.split("\n\n") if chunk.strip()]

def vectorize_chunks(chunks: list[str]) -> list[dict]:
        vectors = []
        print(f"📦 Number of chunks received: {len(chunks)}")
        for chunk in chunks:

            response = requests.post(
                EMBEDDINGS_API_URL ,
                json={
                    "model": MODEL_NAME,
                    "prompt": chunk,
                    "options": {"embedding_only": True}
                }
            )
            response.raise_for_status()
            data = response.json()
            embedding = data.get("embedding")
            if embedding:
                vectors.append({"text": chunk, "vector": embedding})
            else:
                raise ValueError(f"Invalid embedding received for chunk: {chunk}")
        return vectors

def ensure_qdrant_collection(client, collection_name: str, vector_size: int):
        try:
            collections = client.get_collections().collections
            existing_collections = [col.name for col in collections]

            print(f"🔍 Checking Qdrant for collection: {collection_name}")
            if collection_name in existing_collections:
                print(f"✅ Collection `{collection_name}` already exists. Skipping creation.")
                return

            # Attempt to create the collection
            try:
                client.create_collection(
                    collection_name=collection_name,
                    vectors_config=VectorParams(
                        size=vector_size,
                        distance=Distance.COSINE,
                        on_disk=True
                    ),
                    quantization_config=ScalarQuantization(
                        scalar=ScalarQuantizationConfig(
                            type=ScalarType.INT8,
                            always_ram=True
                        )
                    )
                )
                print(f"🎉 Collection `{collection_name}` created successfully.")
            except UnexpectedResponse as e:
                if "already exists" in str(e):
                    print(f"⚠️ Collection `{collection_name}` already exists (caught during race). Continuing.")
                else:
                    raise e

        except Exception as e:
            print(f"❌ Error ensuring collection `{collection_name}`: {str(e)}")
            raise

def export_to_qdrant(vectors: list[dict], file_path: str, collection_name: str = QDRANT_COLLECTION):
    client = QdrantClient(url=QDRANT_URL)
    vector_size = len(vectors[0]["vector"])
    ensure_qdrant_collection(client, collection_name, vector_size)

    points = [
        PointStruct(id=str(uuid.uuid4()), vector=v["vector"], payload={"text": v["text"], "source_file": os.path.basename(file_path)})
        for v in vectors
    ]
    client.upsert(collection_name=collection_name, points=points)
    return {"file_path": file_path, "num_chunks": len(vectors), "status": "success"}