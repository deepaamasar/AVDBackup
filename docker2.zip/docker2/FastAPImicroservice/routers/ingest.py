import os
import shutil
import uuid
from fastapi import APIRouter, UploadFile, File
from utils.file_utils import classify_file_type
from services.ocr_service import run_tesseract_parser, run_digitalfile_parser
from services.chunk_service import chunk_text
from services.vector_service import vectorize_chunks, export_to_qdrant
from services.db_service import log_document_metadata

UPLOAD_DIR = "/tmp/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

router = APIRouter(prefix="/ingest", tags=["Ingestion"])

@router.post("/")
async def ingest_document(file: UploadFile = File(...)):
    file_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file.filename}")
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # classify & extract
    file_type = classify_file_type(file_path)
    if file_type == "pdf_image":
        text = run_tesseract_parser(file_path)
    elif file_type == "pdf_text":
        text = run_digitalfile_parser(file_path)
    else:
        text = ""

    # pipeline
    chunks = chunk_text(text, strategy="Fixed", chunk_size=500)
    vectors = vectorize_chunks(chunks)
    export_result = export_to_qdrant(vectors, file_path)
    log_document_metadata(export_result)

    return {
        "file_id": file_id,
        "filename": file.filename,
        "file_type": file_type,
        "num_chunks": len(chunks),
        "status": "success",
    }
