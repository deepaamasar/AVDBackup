def chunk_by_chars(text, chunk_size=500):
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

text = "This is a long text that needs to be split into equal parts..."
chunks = chunk_by_chars(text, 20)
for idx, chunk in enumerate(chunks, 1):
    print(f"Chunk {idx}: {chunk}")




    def chunk_by_words(text, chunk_size=5000):
      words = text.split()
      return [
        " ".join(words[i:i+chunk_size]) 
        for i in range(0, len(words), chunk_size)
        ]

text = "This is an example text that should be split by words and not cut in the middle."
chunks = chunk_by_words(text, 10)

for i, c in enumerate(chunks, 1):
    print(f"Chunk {i}: {c}")




with open("C:/docker/data/NoisyText.txt", "r", encoding="utf-8") as f:
    text = f.read()

# --- Chunking Functions ---

def chunk_by_words(text, chunk_size=100):
    """Split text into chunks with fixed number of words."""
    words = text.split()
    return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]

def chunk_by_chars_safe(text, max_chars=500):
    """Split text into ~N character chunks, but don’t break words."""
    words = text.split()
    chunks, current = [], ""
    for word in words:
        if len(current) + len(word) + 1 <= max_chars:
            current += (" " if current else "") + word
        else:
            chunks.append(current)
            current = word
    if current:
        chunks.append(current)
    return chunks

# --- Usage ---

print("Word-based chunks (50 words each):")
for i, chunk in enumerate(chunk_by_words(text, 50), 1):
    print(f"\nChunk {i}:\n{chunk}\n")

print("="*80)

print("Character-based chunks (200 chars each, word-safe):")
for i, chunk in enumerate(chunk_by_chars_safe(text, 200), 1):
    print(f"\nChunk {i}:\n{chunk}\n")