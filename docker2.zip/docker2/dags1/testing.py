from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

def start():
    print("✅ DAG has started!")

def end():
    print("🏁 DAG has finished!")

with DAG(
    dag_id="testing",
    start_date=datetime(2025, 8, 1),
    schedule=None,
    catchup=False,               # Do not backfill past runs
    tags=["example"]
) as dag:

    start_task = PythonOperator(
        task_id="start_task",
        python_callable=start
    )

    end_task = PythonOperator(
        task_id="end_task",
        python_callable=end
    )

    start_task >> end_task