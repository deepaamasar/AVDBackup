import spacy
from sentence_transformers import SentenceTransformer, util

# Load models
nlp = spacy.load("en_core_web_sm")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

def semantic_chunk(text, similarity_threshold=0.6, max_sentences=5):
    doc = nlp(text)
    sentences = [sent.text.strip() for sent in doc.sents]

    chunks, current = [], []
    embeddings = embedder.encode(sentences, convert_to_tensor=True)

    for i in range(len(sentences)):
        current.append(sentences[i])

        # Break if topic drifts or max sentence limit
        if i < len(sentences)-1:
            sim = util.cos_sim(embeddings[i], embeddings[i+1]).item()
            if sim < similarity_threshold or len(current) >= max_sentences:
                chunks.append(" ".join(current))
                current = []
    if current:
        chunks.append(" ".join(current))

    return chunks

text = """Artificial intelligence is transforming healthcare. Doctors now rely on AI to detect diseases at early stages, sometimes even before symptoms appear. Machine learning models analyze X-rays, MRIs, and pathology reports with accuracy that rivals human experts. Hospitals also use AI to predict patient outcomes and optimize treatment plans.

In the world of finance, AI powers algorithmic trading systems that execute millions of transactions in milliseconds. Banks deploy AI for fraud detection, spotting unusual patterns in vast streams of transaction data. Customer service chatbots answer queries instantly, while robo-advisors provide personalized investment suggestions to retail clients.

Education has also felt the impact of AI. Adaptive learning systems adjust the pace of lessons based on each student’s performance. Teachers receive insights on where learners struggle the most, allowing them to intervene effectively. Language learning apps use AI-driven speech recognition to correct pronunciation in real time.

Beyond classrooms, AI is addressing global challenges such as climate change. Smart sensors monitor energy grids and predict power demands with remarkable precision. AI-driven weather models help governments prepare for natural disasters. Farmers adopt AI tools to optimize irrigation, reduce fertilizer use, and improve crop yields.

Even the creative industries have embraced AI. Musicians experiment with AI to compose melodies. Visual artists collaborate with algorithms to generate abstract patterns and digital paintings. Writers use AI tools to brainstorm ideas, summarize research, and overcome writer’s block. While debates about originality and ethics continue, the synergy between human imagination and AI tools is undeniable.
"""

for idx, chunk in enumerate(semantic_chunk(text), 1):
    print(f"\nChunk {idx}: {chunk}")