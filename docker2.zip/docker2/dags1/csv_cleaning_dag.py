from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
#from airflow.utils.dates import days_ago
from datetime import datetime
import pandas as pd
import numpy as np
import json
import os
import logging
from typing import Dict, List, Any, Optional
import re
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CSVDataCleaner:
    """Reusable CSV data cleaning class with configuration-driven cleaning methods"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.cleaning_stats = {
            'total_records_processed': 0,
            'records_cleaned': 0,
            'errors_found': 0,
            'files_created': 0,
            'cleaning_operations': {}
        }
    
    def clean_date_column(self, df: pd.DataFrame, column: str, date_config: Dict) -> pd.DataFrame:
        """Clean date columns based on configuration"""
        logger.info(f"Cleaning date column: {column}")
        
        original_nulls = df[column].isnull().sum()
        
        try:
            # Convert to datetime with specified format
            date_format = date_config.get('format', '%Y-%m-%d')
            df[column] = pd.to_datetime(df[column], format=date_format, errors='coerce')
            
            # Handle date range validation
            if 'min_date' in date_config:
                min_date = pd.to_datetime(date_config['min_date'])
                df.loc[df[column] < min_date, column] = np.nan
            
            if 'max_date' in date_config:
                max_date = pd.to_datetime(date_config['max_date'])
                df.loc[df[column] > max_date, column] = np.nan
            
            # Fill missing dates if specified
            if date_config.get('fill_missing'):
                fill_method = date_config.get('fill_method', 'forward')
                if fill_method == 'forward':
                    df[column] = df[column].fillna(method='ffill')
                elif fill_method == 'backward':
                    df[column] = df[column].fillna(method='bfill')
                elif fill_method == 'default':
                    default_date = pd.to_datetime(date_config.get('default_value', '1900-01-01'))
                    df[column] = df[column].fillna(default_date)
            
            new_nulls = df[column].isnull().sum()
            errors_found = new_nulls - original_nulls
            
            self.cleaning_stats['cleaning_operations'][f'{column}_date'] = {
                'original_nulls': int(original_nulls),
                'new_nulls': int(new_nulls),
                'errors_corrected': max(0, int(errors_found))
            }
            
            logger.info(f"Date cleaning completed for {column}: {errors_found} errors found/corrected")
            
        except Exception as e:
            logger.error(f"Error cleaning date column {column}: {str(e)}")
            self.cleaning_stats['errors_found'] += 1
        
        return df
    
    def clean_string_column(self, df: pd.DataFrame, column: str, string_config: Dict) -> pd.DataFrame:
        """Clean string columns based on configuration"""
        logger.info(f"Cleaning string column: {column}")
        
        original_nulls = df[column].isnull().sum()
        
        try:
            # Convert to string
            df[column] = df[column].astype(str)
            
            # Remove leading/trailing whitespace
            if string_config.get('strip', True):
                df[column] = df[column].str.strip()
            
            # Case conversion
            case_conversion = string_config.get('case')
            if case_conversion == 'upper':
                df[column] = df[column].str.upper()
            elif case_conversion == 'lower':
                df[column] = df[column].str.lower()
            elif case_conversion == 'title':
                df[column] = df[column].str.title()
            
            # Remove special characters
            if string_config.get('remove_special_chars'):
                pattern = string_config.get('special_chars_pattern', r'[^a-zA-Z0-9\s]')
                df[column] = df[column].str.replace(pattern, '', regex=True)
            
            # Length validation
            min_length = string_config.get('min_length')
            max_length = string_config.get('max_length')
            
            if min_length:
                df.loc[df[column].str.len() < min_length, column] = np.nan
            if max_length:
                df[column] = df[column].str.slice(0, max_length)
            
            # Replace empty strings with NaN
            df[column] = df[column].replace(['', 'nan', 'None', 'null'], np.nan)
            
            # Fill missing values
            if string_config.get('fill_missing'):
                fill_value = string_config.get('default_value', 'Unknown')
                df[column] = df[column].fillna(fill_value)
            
            new_nulls = df[column].isnull().sum()
            
            self.cleaning_stats['cleaning_operations'][f'{column}_string'] = {
                'original_nulls': int(original_nulls),
                'new_nulls': int(new_nulls),
                'records_processed': len(df)
            }
            
            logger.info(f"String cleaning completed for {column}")
            
        except Exception as e:
            logger.error(f"Error cleaning string column {column}: {str(e)}")
            self.cleaning_stats['errors_found'] += 1
        
        return df
    
    def clean_integer_column(self, df: pd.DataFrame, column: str, int_config: Dict) -> pd.DataFrame:
        """Clean integer columns based on configuration"""
        logger.info(f"Cleaning integer column: {column}")
        
        original_nulls = df[column].isnull().sum()
        
        try:
            # Convert to numeric, errors to NaN
            df[column] = pd.to_numeric(df[column], errors='coerce')
            
            # Round to integers
            df[column] = df[column].round(0)
            
            # Range validation
            min_value = int_config.get('min_value')
            max_value = int_config.get('max_value')
            
            if min_value is not None:
                df.loc[df[column] < min_value, column] = np.nan
            if max_value is not None:
                df.loc[df[column] > max_value, column] = np.nan
            
            # Remove outliers using IQR method if specified
            if int_config.get('remove_outliers'):
                Q1 = df[column].quantile(0.25)
                Q3 = df[column].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                df.loc[(df[column] < lower_bound) | (df[column] > upper_bound), column] = np.nan
            
            # Fill missing values
            if int_config.get('fill_missing'):
                fill_method = int_config.get('fill_method', 'mean')
                if fill_method == 'mean':
                    df[column] = df[column].fillna(df[column].mean())
                elif fill_method == 'median':
                    df[column] = df[column].fillna(df[column].median())
                elif fill_method == 'mode':
                    df[column] = df[column].fillna(df[column].mode().iloc[0] if not df[column].mode().empty else 0)
                elif fill_method == 'default':
                    df[column] = df[column].fillna(int_config.get('default_value', 0))
            
            # Convert to integer type
            df[column] = df[column].astype('Int64')  # Nullable integer type
            
            new_nulls = df[column].isnull().sum()
            
            self.cleaning_stats['cleaning_operations'][f'{column}_integer'] = {
                'original_nulls': int(original_nulls),
                'new_nulls': int(new_nulls),
                'mean_value': float(df[column].mean()) if not df[column].isnull().all() else None,
                'median_value': float(df[column].median()) if not df[column].isnull().all() else None
            }
            
            logger.info(f"Integer cleaning completed for {column}")
            
        except Exception as e:
            logger.error(f"Error cleaning integer column {column}: {str(e)}")
            self.cleaning_stats['errors_found'] += 1
        
        return df
    
    def clean_float_column(self, df: pd.DataFrame, column: str, float_config: Dict) -> pd.DataFrame:
        """Clean float columns based on configuration"""
        logger.info(f"Cleaning float column: {column}")
        
        original_nulls = df[column].isnull().sum()
        
        try:
            # Convert to numeric, errors to NaN
            df[column] = pd.to_numeric(df[column], errors='coerce')
            
            # Precision rounding
            precision = float_config.get('precision', 2)
            df[column] = df[column].round(precision)
            
            # Range validation
            min_value = float_config.get('min_value')
            max_value = float_config.get('max_value')
            
            if min_value is not None:
                df.loc[df[column] < min_value, column] = np.nan
            if max_value is not None:
                df.loc[df[column] > max_value, column] = np.nan
            
            # Remove outliers using IQR method if specified
            if float_config.get('remove_outliers'):
                Q1 = df[column].quantile(0.25)
                Q3 = df[column].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                df.loc[(df[column] < lower_bound) | (df[column] > upper_bound), column] = np.nan
            
            # Fill missing values
            if float_config.get('fill_missing'):
                fill_method = float_config.get('fill_method', 'mean')
                if fill_method == 'mean':
                    df[column] = df[column].fillna(df[column].mean())
                elif fill_method == 'median':
                    df[column] = df[column].fillna(df[column].median())
                elif fill_method == 'default':
                    df[column] = df[column].fillna(float_config.get('default_value', 0.0))
            
            new_nulls = df[column].isnull().sum()
            
            self.cleaning_stats['cleaning_operations'][f'{column}_float'] = {
                'original_nulls': int(original_nulls),
                'new_nulls': int(new_nulls),
                'mean_value': float(df[column].mean()) if not df[column].isnull().all() else None,
                'std_value': float(df[column].std()) if not df[column].isnull().all() else None,
                'min_value': float(df[column].min()) if not df[column].isnull().all() else None,
                'max_value': float(df[column].max()) if not df[column].isnull().all() else None
            }
            
            logger.info(f"Float cleaning completed for {column}")
            
        except Exception as e:
            logger.error(f"Error cleaning float column {column}: {str(e)}")
            self.cleaning_stats['errors_found'] += 1
        
        return df
    
    def process_csv(self, input_file: str, output_dir: str) -> Dict[str, Any]:
        """Main method to process CSV file based on configuration"""
        logger.info(f"Starting CSV processing: {input_file}")
        
        try:
            # Read CSV file
            df = pd.read_csv(input_file)
            self.cleaning_stats['total_records_processed'] = len(df)
            
            logger.info(f"Loaded CSV with {len(df)} records and {len(df.columns)} columns")
            
            # Apply cleaning based on configuration
            columns_config = self.config.get('columns', {})
            
            for column, column_config in columns_config.items():
                if column not in df.columns:
                    logger.warning(f"Column {column} not found in CSV")
                    continue
                
                data_type = column_config.get('type')
                
                if data_type == 'date':
                    df = self.clean_date_column(df, column, column_config)
                elif data_type == 'string':
                    df = self.clean_string_column(df, column, column_config)
                elif data_type == 'integer':
                    df = self.clean_integer_column(df, column, column_config)
                elif data_type == 'float':
                    df = self.clean_float_column(df, column, column_config)
            
            # Remove duplicate rows if specified
            if self.config.get('remove_duplicates', False):
                original_count = len(df)
                df = df.drop_duplicates()
                duplicates_removed = original_count - len(df)
                logger.info(f"Removed {duplicates_removed} duplicate rows")
                self.cleaning_stats['duplicates_removed'] = duplicates_removed
            
            self.cleaning_stats['records_cleaned'] = len(df)
            
            # Split and save files if more than specified threshold
            max_records = self.config.get('max_records_per_file', 1000)
            
            if len(df) > max_records:
                return self._split_and_save_csv(df, output_dir, max_records)
            else:
                output_file = os.path.join(output_dir, f"cleaned_{os.path.basename(input_file)}")
                df.to_csv(output_file, index=False)
                self.cleaning_stats['files_created'] = 1
                logger.info(f"Saved cleaned CSV: {output_file}")
                return {'output_files': [output_file], 'stats': self.cleaning_stats}
        
        except Exception as e:
            logger.error(f"Error processing CSV: {str(e)}")
            self.cleaning_stats['errors_found'] += 1
            raise
    
    def _split_and_save_csv(self, df: pd.DataFrame, output_dir: str, max_records: int) -> Dict[str, Any]:
        """Split large CSV into smaller files"""
        logger.info(f"Splitting CSV into files with max {max_records} records each")
        
        output_files = []
        total_files = (len(df) + max_records - 1) // max_records
        
        for i in range(0, len(df), max_records):
            chunk = df.iloc[i:i + max_records]
            file_num = (i // max_records) + 1
            output_file = os.path.join(output_dir, f"cleaned_part_{file_num}_of_{total_files}.csv")
            chunk.to_csv(output_file, index=False)
            output_files.append(output_file)
            logger.info(f"Created file {file_num}/{total_files}: {output_file} with {len(chunk)} records")
        
        self.cleaning_stats['files_created'] = len(output_files)
        return {'output_files': output_files, 'stats': self.cleaning_stats}

def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from JSON file"""
    with open(config_path, 'r') as f:
        return json.load(f)

def clean_csv_task(**context):
    """Airflow task to clean CSV data"""
    config_path = context['dag_run'].conf.get('config_path', '/path/to/config.json')
    input_file = context['dag_run'].conf.get('input_file', '/path/to/input.csv')
    output_dir = context['dag_run'].conf.get('output_dir', '/path/to/output/')
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Load configuration
    config = load_config(config_path)
    
    # Create cleaner instance and process CSV
    cleaner = CSVDataCleaner(config)
    result = cleaner.process_csv(input_file, output_dir)
    
    # Log analytics
    stats = result['stats']
    logger.info("=== CSV CLEANING ANALYTICS ===")
    logger.info(f"Total records processed: {stats['total_records_processed']}")
    logger.info(f"Records after cleaning: {stats['records_cleaned']}")
    logger.info(f"Files created: {stats['files_created']}")
    logger.info(f"Errors found: {stats['errors_found']}")
    
    if 'duplicates_removed' in stats:
        logger.info(f"Duplicate records removed: {stats['duplicates_removed']}")
    
    logger.info("Column-wise cleaning operations:")
    for operation, details in stats['cleaning_operations'].items():
        logger.info(f"  {operation}: {details}")
    
    # Store results in XCom for downstream tasks
    return result

# Define DAG
default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    #'start_date': days_ago(1),
    'start_date': datetime(2025, 8, 4),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'csv_data_cleaning_pipeline',
    default_args=default_args,
    description='CSV Data Cleaning Pipeline with Configuration',
    schedule=None,  # Triggered manually
    catchup=False,
    tags=['data-cleaning', 'csv', 'etl'],
)

# Define tasks
clean_csv = PythonOperator(
    task_id='clean_csv_data',
    python_callable=clean_csv_task,
    dag=dag,
)

# Task dependencies (can add more tasks like validation, notifications, etc.)
clean_csv