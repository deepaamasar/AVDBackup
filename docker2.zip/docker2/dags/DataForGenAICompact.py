import requests
from airflow import DAG
from airflow.decorators import task
from airflow.models import Variable
from airflow.operators.python import get_current_context
from airflow.sensors.python import PythonSensor
from datetime import datetime, timedelta
import time

# CONFIG
SHARED_FOLDER = Variable.get("idp_input_folder", "\\\\AVDGENAIL18-3\\temp")
USER_ID = Variable.get("user_id", "your_user")
PASSWORD = Variable.get("password", "your_pass")
NUM_FILES = int(Variable.get("docs_per_run", 2))
PIPELINE_NAME = "GenAICompact1"
# API URLs
INGEST_API_URL = "http://host.docker.internal:8000/ingest/files"
INGEST_STATUS_URL = "http://host.docker.internal:8000/ingest/status/{ingest_task_id}"
PARSER_API_URL = "http://host.docker.internal:8000/parser/parse"
PARSER_STATUS_URL = "http://host.docker.internal:8000/parser/status/{parser_task_id}"
TEXTPROC_API_URL = "http://host.docker.internal:8000/textprocessing/process"
TEXTPROC_STATUS_URL = "http://host.docker.internal:8000/textprocessing/status/{textproc_task_id}"
CHUNK_API_URL = "http://host.docker.internal:8000/chunking/chunk"
CHUNK_STATUS_URL = "http://host.docker.internal:8000/chunking/status/{chunk_task_id}"
VECTORIZER_API_URL = "http://host.docker.internal:8000/vectorize/embed"
VECTORIZER_STATUS_URL = "http://host.docker.internal:8000/vectorize/status/{vectorize_task_id}"
EXPORT_API_URL = "http://host.docker.internal:8000/export/data"
EXPORT_STATUS_URL = "http://host.docker.internal:8000/export/status/{export_task_id}"

def poll_status(url, task_id, key="status", target="completed", timeout=600, interval=10):
    retry_count = 3
    total_attempts = timeout // interval
    
    for attempt in range(total_attempts):
        for retry in range(retry_count):
            try:
                resp = requests.get(url.format(task_id=task_id), timeout=30)
                resp.raise_for_status()
                status_json = resp.json()
                status = status_json.get(key)
                
                print(f"Polling status for task {task_id}: {status} (attempt {attempt + 1}/{total_attempts}, retry {retry + 1}/{retry_count})")
                
                if status == target:
                    return status_json
                elif status in ["failed", "error"]:
                    raise Exception(f"Task {task_id} failed with status: {status}")
                
                # Break out of retry loop if request succeeded
                break
                
            except requests.exceptions.RequestException as e:
                print(f"Network error polling task {task_id} (retry {retry + 1}/{retry_count}): {e}")
                if retry == retry_count - 1:
                    print(f"Max retries exceeded for task {task_id}")
                    raise Exception(f"Failed to poll task {task_id} after {retry_count} network retries: {e}")
                time.sleep(5)  # Short wait before retry
                
        time.sleep(interval)
    
    raise TimeoutError(f"Task {task_id} did not reach status '{target}' in {timeout} seconds.")

def poll_parser_status():
    context = get_current_context()
    ti = context['ti']
    result = ti.xcom_pull(task_ids='parser')

    if not result:
        print("Parser result not found, waiting...")
        return False

    parser_task_id = result.get('parser_task_id')
    folder_id = result.get('folder_id')
    if not parser_task_id:
        print("Parser task_id missing, waiting...")
        return False
    status_url = f"http://host.docker.internal:8000/parser/status/{parser_task_id}"
    try:
        status_resp = requests.get(status_url, timeout=30)
        status_resp.raise_for_status()
        status_json = status_resp.json()
        status = status_json.get("status")
        print(f"Parser status for {parser_task_id}: {status}")
        if status in ["success", "completed"]:
            ti.xcom_push(key=f"parser_folder_{parser_task_id}", value=folder_id)
            return True
        elif status in ["failed", "error"]:
            print(f"Parser task {parser_task_id} failed with status: {status}")
            raise Exception(f"Parser task {parser_task_id} failed with status: {status}")
        else:
            print(f"Parser task {parser_task_id} status: {status}, waiting...")
            return False
    except requests.exceptions.RequestException as e:
        print(f"Network error polling parser status for {parser_task_id}: {e}")
        return False
    except Exception as e:
        print(f"Error polling parser status for {parser_task_id}: {e}")
        raise

def poll_ingest_status():
    # retrieve Airflow context for sensor
    context = get_current_context()
    ti = context['ti']
    ingest_result = ti.xcom_pull(task_ids='ingest_files')

    if not ingest_result or 'ingest_task_id' not in ingest_result:
        print("Ingest task ID not found in task result, waiting...")
        return False

    ingest_task_id = ingest_result['ingest_task_id']
    job_id = ingest_result.get('job_id')

    status_url = f"http://host.docker.internal:8000/ingest/status/{ingest_task_id}"
    try:
        status_resp = requests.get(status_url, timeout=30)
        status_resp.raise_for_status()
        status_json = status_resp.json()
        print(f"Ingest status response: {status_json}")
        status = status_json.get("status")
        folder_ids = status_json.get("folder_ids")

        if status in ["success", "completed"] and folder_ids:
            print(f"Ingest task completed. Folders: {folder_ids}")
            ti.xcom_push(key="folders", value=folder_ids)
            ti.xcom_push(key="job_id", value=job_id)
            return True
        elif status in ["failed", "error"]:
            print(f"Ingest task failed with status: {status}")
            raise Exception(f"Ingest task failed with status: {status}")
        else:
            print(f"Ingest task status: {status}, waiting for completion...")
            return False
    except requests.exceptions.RequestException as e:
        print(f"Network error polling ingest status: {e}")
        return False
    except Exception as e:
        print(f"Error polling ingest status: {e}")
        raise

def poll_textproc_status():
        context = get_current_context()
        ti = context['ti']
        result = ti.xcom_pull(task_ids='text_processing')
        if not result:
            print("Text Processing result not found, waiting...")
            return False
        textproc_task_id = result.get('textproc_task_id')
        folder_id = result.get('folder_id')
        if not textproc_task_id:
            print("Text Processing task_id missing, waiting...")
            return False
        status_url = f"http://host.docker.internal:8000/textprocessing/status/{textproc_task_id}"
        try:
            status_resp = requests.get(status_url, timeout=30)
            status_resp.raise_for_status()
            status_json = status_resp.json()
            status = status_json.get("status")
            print(f"Text Processing status for {textproc_task_id}: {status}")
            if status in ["success", "completed"]:
                ti.xcom_push(key=f"textproc_folder_{textproc_task_id}", value=folder_id)
                return True
            elif status in ["failed", "error"]:
                print(f"Text Processing task {textproc_task_id} failed with status: {status}")
                raise Exception(f"Text Processing task {textproc_task_id} failed with status: {status}")
            else:
                print(f"Text Processing task {textproc_task_id} status: {status}, waiting...")
                return False
        except requests.exceptions.RequestException as e:
            print(f"Network error polling text processing status for {textproc_task_id}: {e}")
            return False
        except Exception as e:
            print(f"Error polling text processing status for {textproc_task_id}: {e}")
            raise

def poll_chunk_status():
        context = get_current_context()
        ti = context['ti']
        result = ti.xcom_pull(task_ids='chunk')
        if not result:
            print("Chunking result not found, waiting...")
            return False
        chunk_task_id = result.get('chunk_task_id')
        folder_id = result.get('folder_id')
        if not chunk_task_id:
            print("Chunking task_id missing, waiting...")
            return False
        status_url = f"http://host.docker.internal:8000/chunking/status/{chunk_task_id}"
        try:
            status_resp = requests.get(status_url, timeout=30)
            status_resp.raise_for_status()
            status_json = status_resp.json()
            status = status_json.get("status")
            print(f"Chunking status for {chunk_task_id}: {status}")
            if status in ["success", "completed"]:
                ti.xcom_push(key=f"chunk_folder_{chunk_task_id}", value=folder_id)
                return True
            elif status in ["failed", "error"]:
                print(f"Chunking task {chunk_task_id} failed with status: {status}")
                raise Exception(f"Chunking task {chunk_task_id} failed with status: {status}")
            else:
                print(f"Chunking task {chunk_task_id} status: {status}, waiting...")
                return False
        except requests.exceptions.RequestException as e:
            print(f"Network error polling chunking status for {chunk_task_id}: {e}")
            return False
        except Exception as e:
            print(f"Error polling chunking status for {chunk_task_id}: {e}")
            raise

def poll_vectorize_status():
        context = get_current_context()
        ti = context['ti']
        result = ti.xcom_pull(task_ids='vectorize')
        if not result:
            print("Vectorization result not found, waiting...")
            return False
        vectorize_task_id = result.get('vectorize_task_id')
        folder_id = result.get('folder_id')
        if not vectorize_task_id:
            print("Vectorization task_id missing, waiting...")
            return False
        status_url = f"http://host.docker.internal:8000/vectorize/status/{vectorize_task_id}"
        try:
            status_resp = requests.get(status_url, timeout=30)
            status_resp.raise_for_status()
            status_json = status_resp.json()
            status = status_json.get("status")
            print(f"Vectorization status for {vectorize_task_id}: {status}")
            if status in ["success", "completed"]:
                ti.xcom_push(key=f"vectorize_folder_{vectorize_task_id}", value=folder_id)
                return True
            elif status in ["failed", "error"]:
                print(f"Vectorization task {vectorize_task_id} failed with status: {status}")
                raise Exception(f"Vectorization task {vectorize_task_id} failed with status: {status}")
            else:
                print(f"Vectorization task {vectorize_task_id} status: {status}, waiting...")
                return False
        except requests.exceptions.RequestException as e:
            print(f"Network error polling vectorization status for {vectorize_task_id}: {e}")
            return False
        except Exception as e:
            print(f"Error polling vectorization status for {vectorize_task_id}: {e}")
            raise

def poll_export_status():
        context = get_current_context()
        ti = context['ti']
        result = ti.xcom_pull(task_ids='export')
        if not result:
            print("Export result not found, waiting...")
            return False
        export_task_id = result.get('export_task_id')
        folder_id = result.get('folder_id')
        if not export_task_id:
            print("Export task_id missing, waiting...")
            return False
        status_url = f"http://host.docker.internal:8000/export/status/{export_task_id}"
        try:
            status_resp = requests.get(status_url, timeout=30)
            status_resp.raise_for_status()
            status_json = status_resp.json()
            status = status_json.get("status")
            print(f"Export status for {export_task_id}: {status}")
            if status in ["success", "completed"]:
                ti.xcom_push(key=f"export_folder_{export_task_id}", value=folder_id)
                return True
            elif status in ["failed", "error"]:
                print(f"Export task {export_task_id} failed with status: {status}")
                raise Exception(f"Export task {export_task_id} failed with status: {status}")
            else:
                print(f"Export task {export_task_id} status: {status}, waiting...")
                return False
        except requests.exceptions.RequestException as e:
            print(f"Network error polling export status for {export_task_id}: {e}")
            return False
        except Exception as e:
            print(f"Error polling export status for {export_task_id}: {e}")
            raise

with DAG(
    dag_id="DataForGenAICompact",
    start_date=datetime(2025, 1, 1),
    schedule=None,
    catchup=False,
    tags=["Pipeline", "Microservices", "Orchestration"],
) as dag:
   
   
    @task
    def ingest_files():
        context = get_current_context()
        job_id = context['run_id'] if 'run_id' in context else PIPELINE_NAME + "_" + str(int(time.time()))
        # Prepare multipart form data
        form_data = {
            "shared_folder_path": (None, SHARED_FOLDER),
            "user_id": (None, USER_ID),
            "password": (None, PASSWORD),
            "num_files": (None, str(NUM_FILES)),
            "pipeline_name": (None, PIPELINE_NAME),
            "job_name": (None, job_id)
        }
        resp = requests.post(
            "http://host.docker.internal:8000/ingest/files",
            files=form_data,
            timeout=120  # 5 minute timeout
        )
        resp.raise_for_status()
        resp_json = resp.json()
        print(f"Ingest API response: {resp_json}")
        ingest_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Retrieved ingest_task_id: {ingest_task_id}, status: {status}")
        return {"job_id": job_id, "ingest_task_id": ingest_task_id, "status": status}

    @task()
    def parser(folder_id):
        print(f"Calling Parser API for folder {folder_id}")
        form_data = {
            "folder_id": (None, folder_id),
            "parser_name": (None, "Tesseract")
        }
        resp = requests.post(
            "http://host.docker.internal:8000/parser/parse",
            files=form_data,
            timeout=120
        )
        resp.raise_for_status()
        resp_json = resp.json()
        parser_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Parser API response for folder {folder_id}: task_id={parser_task_id}, status={status}")
        return {
            "folder_id": folder_id,
            "parser_task_id": parser_task_id,
            "status": status
        }

    @task()
    def text_processing(folder_id):
        print(f"Calling Text Processing API for folder {folder_id}")
        form_data = {
            "folder_id": (None, folder_id),
            "textprocessings": (None, "remove page numbers")  # If multiple, join as comma-separated string
        }
        resp = requests.post(
            "http://host.docker.internal:8000/textprocessing/process",
            files=form_data,
            timeout=120
        )
        resp.raise_for_status()
        resp_json = resp.json()
        textproc_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Text Processing API response for folder {folder_id}: task_id={textproc_task_id}, status={status}")
        return {
            "folder_id": folder_id,
            "textproc_task_id": textproc_task_id,
            "status": status
        }

    @task()
    def chunk(folder_id):
        print(f"Calling Chunking API for folder {folder_id}")
        form_data = {
            "folder_id": (None, folder_id),
            "chunking_strategies": (None, "fixed characters,500,50")  # Join strategies as comma-separated string
        }
        resp = requests.post(
            "http://host.docker.internal:8000/chunking/chunk",
            files=form_data,
            timeout=120
        )
        resp.raise_for_status()
        resp_json = resp.json()
        chunk_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Chunking API response for folder {folder_id}: task_id={chunk_task_id}, status={status}")
        return {
            "folder_id": folder_id,
            "chunk_task_id": chunk_task_id,
            "status": status
        }

    @task()
    def vectorize(folder_id):
        print(f"Calling Vectorization API for folder {folder_id}")
        form_data = {
            "folder_id": (None, folder_id),
            "vectorize_strategy": (None, "nomic-embed-text,768")  # Join strategies as comma-separated string
        }
        resp = requests.post(
            "http://host.docker.internal:8000/vectorize/embed",
            files=form_data,
            timeout=120
        )
        resp.raise_for_status()
        resp_json = resp.json()
        vectorize_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Vectorization API response for folder {folder_id}: task_id={vectorize_task_id}, status={status}")
        return {
            "folder_id": folder_id,
            "vectorize_task_id": vectorize_task_id,
            "status": status
        }

    @task()
    def export(folder_id):
        print(f"Calling Export API for folder {folder_id}")
        form_data = {
            "folder_id": (None, folder_id),
            "export_strategy": (None, "csv,json")  # Join strategies as comma-separated string
        }
        resp = requests.post(
            "http://host.docker.internal:8000/export/data",
            files=form_data,
            timeout=120
        )
        resp.raise_for_status()
        resp_json = resp.json()
        export_task_id = resp_json.get("task_id")
        status = resp_json.get("status")
        print(f"Export API response for folder {folder_id}: task_id={export_task_id}, status={status}")
        return {
            "folder_id": folder_id,
            "export_task_id": export_task_id,
            "status": status
        }

    ingest_result = ingest_files()
    ingest_sensor = PythonSensor(
        task_id='wait_for_ingest_completion',
        python_callable=poll_ingest_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )

    @task()
    def extract_folders_from_xcom(ti=None):
        """Extract folders list from XCom after ingest sensor."""
        if ti is None:
            from airflow.decorators import get_current_context
            ti = get_current_context()['ti']
        folders = ti.xcom_pull(task_ids='wait_for_ingest_completion', key='folders')
        print(f"Extracted folders from XCom: {folders}")
        return folders

    folders_list = extract_folders_from_xcom()
    parser_results = parser.expand(
        folder_id=folders_list
    )
    parser_sensor = PythonSensor(
        task_id='wait_for_parser_completion',
        python_callable=poll_parser_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )
    textproc_results = text_processing.expand(
        folder_id=parser_results
    )
    textproc_sensor = PythonSensor(
        task_id='wait_for_textproc_completion',
        python_callable=poll_textproc_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )
    chunk_results = chunk.expand(
        folder_id=textproc_results
    )
    chunk_sensor = PythonSensor(
        task_id='wait_for_chunk_completion',
        python_callable=poll_chunk_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )
    vectorize_results = vectorize.expand(
        folder_id=chunk_results
    )
    vectorize_sensor = PythonSensor(
        task_id='wait_for_vectorize_completion',
        python_callable=poll_vectorize_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )
    export_results = export.expand(
        folder_id=vectorize_results
    )
    export_sensor = PythonSensor(
        task_id='wait_for_export_completion',
        python_callable=poll_export_status,
        poke_interval=60,
        timeout=3600,
        mode='reschedule',
        soft_fail=False,
        retries=0,
        dag=dag
    )

    # Updated dependency chain with export sensor
    ingest_result >> ingest_sensor
    ingest_sensor >> folders_list
    folders_list >> parser_results
    parser_results >> parser_sensor
    parser_sensor >> textproc_results
    textproc_results >> textproc_sensor
    textproc_sensor >> chunk_results
    chunk_results >> chunk_sensor
    chunk_sensor >> vectorize_results
    vectorize_results >> vectorize_sensor
    vectorize_sensor >> export_results
    export_results >> export_sensor
