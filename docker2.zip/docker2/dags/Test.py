from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'retries': 0,
}

with DAG(
    dag_id='metrics_test_dag',
    default_args=default_args,
    description='DAG to test StatsD metrics flow',
    schedule_interval=None,  # manual trigger
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=['metrics', 'test'],
) as dag:

    start = BashOperator(
        task_id='start_task',
        bash_command='echo "Starting DAG"; sleep 5',
    )

    fail_task = BashOperator(
        task_id='fail_task',
        bash_command='exit 1',   # will fail → generates task failure metric
    )

    end = BashOperator(
        task_id='end_task',
        bash_command='echo "DAG finished successfully"; sleep 3',
        trigger_rule='all_done',  # runs even if fail_task fails
    )

    start >> fail_task >> end
